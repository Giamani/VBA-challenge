{\rtf1\ansi\ansicpg1252\cocoartf2759
\cocoatextscaling0\cocoaplatform0{\fonttbl\f0\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;}
{\*\expandedcolortbl;;}
\margl1440\margr1440\vieww11520\viewh8400\viewkind0
\pard\tx566\tx1133\tx1700\tx2267\tx2834\tx3401\tx3968\tx4535\tx5102\tx5669\tx6236\tx6803\pardirnatural\partightenfactor0

\f0\fs24 \cf0 \
Sub StockAnalysisOnAllSheets()\
    ' Defining variables\
    Dim ws As Worksheet\
    Dim lastRow As Long\
    Dim ticker As String\
    Dim openingPrice As Double\
    Dim closingPrice As Double\
    Dim yearlyChange As Double\
    Dim percentChange As Double\
    Dim totalVolume As Double\
    Dim summaryRow As Integer\
    Dim greatestPercentIncrease As Double\
    Dim greatestPercentDecrease As Double\
    Dim greatestTotalVolume As Double\
    Dim greatestPercentIncreaseTicker As String\
    Dim greatestPercentDecreaseTicker As String\
    Dim greatestTotalVolumeTicker As String\
    \
    ' Initializing variables for greatest values\
    greatestPercentIncrease = 0\
    greatestPercentDecrease = 0\
    greatestTotalVolume = 0\
    greatestPercentIncreaseTicker = ""\
    greatestPercentDecreaseTicker = ""\
    greatestTotalVolumeTicker = ""\
    \
    ' Looping through each worksheet\
    For Each ws In ThisWorkbook.Worksheets\
        ' Checking if the sheet name contains the years 2018, 2019, or 2020\
        If InStr(1, UCase(ws.Name), "2018") > 0 Or InStr(1, UCase(ws.Name), "2019") > 0 Or InStr(1, UCase(ws.Name), "2020") > 0 Then\
            ' Finding the last row of data in the worksheet\
            lastRow = ws.Cells(Rows.Count, 1).End(xlUp).Row\
            \
            ' Seting initial values for summary variables\
            ticker = ""\
            openingPrice = 0\
            closingPrice = 0\
            yearlyChange = 0\
            percentChange = 0\
            totalVolume = 0\
            summaryRow = 2\
            \
            ' Genrating column names\
            ws.Range("I1").Value = "Ticker"\
            ws.Range("J1").Value = "Yearly Change"\
            ws.Range("K1").Value = "Percent Change"\
            ws.Range("L1").Value = "Total Stock Volume"\
            \
            ' Looping through each row in the worksheet\
            For i = 2 To lastRow\
                ' Checking if the ticker symbol has changed\
                If ws.Cells(i, 1).Value <> ws.Cells(i - 1, 1).Value Then\
                    ' Storing the opening price for the new ticker symbol\
                    openingPrice = ws.Cells(i, 3).Value\
                End If\
                \
                ' Calculating the total volume for each ticker symbol\
                totalVolume = totalVolume + ws.Cells(i, 7).Value\
                \
                ' Checking if the ticker symbol has changed or it's the last row\
                If ws.Cells(i, 1).Value <> ws.Cells(i + 1, 1).Value Or i = lastRow Then\
                    ' Storing the closing price for the current ticker symbol\
                    closingPrice = ws.Cells(i, 6).Value\
                    \
                    ' Calculating the yearly change and percent change\
                    yearlyChange = closingPrice - openingPrice\
                    percentChange = yearlyChange / openingPrice\
                    \
                    ' Outputing the results to the summary table\
                    ws.Cells(summaryRow, 9).Value = ws.Cells(i, 1).Value\
                    ws.Cells(summaryRow, 10).Value = yearlyChange\
                    ws.Cells(summaryRow, 11).Value = percentChange\
                    ws.Cells(summaryRow, 12).Value = totalVolume\
                    \
                    ' Formating the percent change as percentage\
                    ws.Cells(summaryRow, 11).NumberFormat = "0.00%"\
                    \
                    ' Highlighting positive change in green and negative change in red\
                    If yearlyChange > 0 Then\
                        ws.Cells(summaryRow, 10).Interior.Color = RGB(0, 255, 0)\
                    ElseIf yearlyChange < 0 Then\
                        ws.Cells(summaryRow, 10).Interior.Color = RGB(255, 0, 0)\
                    End If\
                    \
                    ' Checking for greatest percent increase, decrease, and total volume\
                    If percentChange > greatestPercentIncrease Then\
                        greatestPercentIncrease = percentChange\
                        greatestPercentIncreaseTicker = ws.Cells(i, 1).Value\
                    End If\
                    \
                    If percentChange < greatestPercentDecrease Then\
                        greatestPercentDecrease = percentChange\
                        greatestPercentDecreaseTicker = ws.Cells(i, 1).Value\
                    End If\
                    \
                    If totalVolume > greatestTotalVolume Then\
                        greatestTotalVolume = totalVolume\
                        greatestTotalVolumeTicker = ws.Cells(i, 1).Value\
                    End If\
                    \
                    ' Moveing to the next row in the summary table\
                    summaryRow = summaryRow + 1\
                    \
                    ' Reseting the summary variables for the next ticker symbol\
                    ticker = ""\
                    openingPrice = 0\
                    closingPrice = 0\
                    yearlyChange = 0\
                    percentChange = 0\
                    totalVolume = 0\
                End If\
            Next i\
            \
            ' Generating greatest values to specified cells on the corresponding sheets\
            ws.Range("O2").Value = "Greatest % Increase"\
            ws.Range("O3").Value = "Greatest % Decrease"\
            ws.Range("O4").Value = "Greatest Total Volume"\
            \
            ws.Range("P1").Value = "Ticker"\
            ws.Range("Q1").Value = "Value"\
            ws.Range("P2").Value = greatestPercentIncreaseTicker\
            ws.Range("Q2").Value = greatestPercentIncrease * 100\
            ws.Range("P3").Value = greatestPercentDecreaseTicker\
            ws.Range("Q3").Value = greatestPercentDecrease * 100\
            ws.Range("P4").Value = greatestTotalVolumeTicker\
            ws.Range("Q4").Value = greatestTotalVolume\
        End If\
    Next ws\
End Sub\
\
}